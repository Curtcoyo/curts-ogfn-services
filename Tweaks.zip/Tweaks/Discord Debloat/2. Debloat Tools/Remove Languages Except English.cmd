@echo off
cd /d %LOCALAPPDATA%\Discord\app-1.0.* >nul 2>&1
copy "locales\en-US.pak" "%LOCALAPPDATA%\Discord\" >nul 2>&1
rmdir /s /q "locales" >nul 2>&1
mkdir "locales" >nul 2>&1
move "%LOCALAPPDATA%\Discord\en-US.pak" "locales" >nul 2>&1
echo Completed!
echo Press Any Key To Open Our Social Media Link :)
pause > nul
start https://www.tiktok.com/@zyrixtweaks