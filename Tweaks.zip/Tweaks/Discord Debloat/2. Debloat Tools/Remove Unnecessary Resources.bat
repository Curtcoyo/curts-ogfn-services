@echo off
cd /d %LOCALAPPDATA%\Discord\app-1.0.*\modules >nul 2>&1
for %%a in ("discord_cloudsync-1" "discord_dispatch-1" "discord_erlpack-1" "discord_game_utils-1" "discord_media-1" "discord_spellcheck-1" "discord_hook-1") do rmdir /s /q "%%~a" >nul 2>&1
echo Completed!
echo Press Any Key To Open Our Social Media Link :)
pause > nul
start https://www.tiktok.com/@zyrixtweaks