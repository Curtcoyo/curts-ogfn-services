@echo off
set REMOVE_OVERLAY=YES

if /i "%REMOVE_OVERLAY%"=="YES" (
    cd /d %LOCALAPPDATA%\Discord\app-1.0.*\modules   >nul 2>&1
    for %%b in ("discord_rpc-1" "discord_overlay-1") do rmdir /s /q "%%~b"  >nul 2>&1
)
echo Completed!
echo Press Any Key To Open Our Social Media Link :)
pause > nul
start https://www.tiktok.com/@zyrixtweaks